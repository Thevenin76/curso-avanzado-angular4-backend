export const GLOBAL =
{
	app_url: "http://localhost:3789/api",
	app_name: "ngZoo - Planea una visita a nuestro zoo",
	app_copyright: "ngZoo - Copyright 2021"
};
